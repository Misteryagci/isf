J'ai utilisé une partie des fonctions de TD2. Pour analyser une fichjier .wav. J'ai utilisé aussi des fonction de l'analyse spéctrale de la TD3.

Je pense qu'il va falloir utiliser le tranformé de fourrier mais je ne sais comment on peut l'utiliser.

Pour le capture des événement je pense à utiliser les maximum locaux mais je n'ai pas réussi.
